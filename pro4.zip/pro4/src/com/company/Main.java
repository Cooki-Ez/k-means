package com.company;

import java.io.File;
import java.text.DecimalFormat;
import java.util.*;

public final class Main {
    double printingDistance;
    double lastDistance;
    int numberOfIterations;
    int iter = 1;

    public static void main(String[] args) {
        new Main().begin();
    }

    public void begin() {
        Reader reader = new Reader(new File("iris.data.txt")); //read data from file
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter k");
        int k = sc.nextInt();
        System.out.println("Enter iterations");
        Map<String, List<Double>> centroids = new HashMap<>();
        List<Double> xs;
        System.out.println("Starting centroids are");
        for (int i = 0; i < k; i++) {
            System.out.print(1 + i + ")");
            xs = reader.listOfCoordinates.get(new Random().nextInt(105));   //creating k first centroids (just take k first vectors)
            System.out.println(xs);
            centroids.put(String.valueOf(i), xs);
        }
        //System.out.println(centroids);
        Map<List<Double>, Integer> clusters = calculateClusters(reader.listOfCoordinates, centroids);//calculate clusters
        //System.out.println("CLUSTERS VALUES ARE " + clusters.values());
        //System.out.println("CLUSTERS 1 ARE" + clusters);
        List<Double> newCentroidCoords;
        while (lastDistance != printingDistance && printingDistance != 0) {
            numberOfIterations++;
            for (int j = 0; j < centroids.size(); j++) {
                //System.out.println(centroids.size());
                List<List<Double>> list = new ArrayList<>();
                //int i = 1;
                for (var key : clusters.keySet()) {
                    if (clusters.get(key) == j) {
                        //System.out.println(clusters.get(key) + " equals to " + j);
                        //i++;
                        list.add(key);
                    }
                    //else System.out.println(clusters.get(key) + " NOT equals to " + j);
                }
                //System.out.println("i = " + i);
                //System.out.println(list);
                if (list.size() != 0) {
                    newCentroidCoords = calculateCentroids(list);   //calculate new centroids basing on the old ones

                    //System.out.println(newCentroidCoords);
                    centroids.put(String.valueOf(j), newCentroidCoords);
                }
            }
            /*for (var s : centroids.keySet()){
                for (int i = 0; i < centroids.get(s).size(); i++) {
                    if(Double.isNaN(centroids.get(s).get(i))){
                        System.out.println("ITERATION IS " + numberOfIterations + "\nCENTROIDS ARE" + centroids);
                        return;
                    }
                }

            }*/
            //System.out.println("CENTROIDS ARE " + centroids);
            clusters.clear();
            clusters = calculateClusters(reader.listOfCoordinates, centroids);
            //System.out.println("CLUSTERS 2 ARE" + clusters);
        }
        System.out.println("Enter \n1 to repeat\n2 to exit");
        int fromUser = sc.nextInt();
        switch (fromUser) {
            case 1 -> begin();
            case 2 -> System.exit(0);
        }
    }

    public List<Double> calculateCentroids(List<List<Double>> a) {
        int count;
        double sum;
        if (a.size() == 0) System.out.println("LIST IS EMPTY IN ITER " + iter++);
        //if(iter > 50) System.exit(0);
        List<Double> centroids = new ArrayList<>(Reader.cap);
        for (int i = 0; i < Reader.cap; i++) {
            sum = 0.0;
            count = 0;
            for (var x : a) {  //add every vector from a list and divide it by quantity, then fill new list of centroids
                count++;
                sum += x.get(i);
            }
            //if(Double.isNaN(sum / count))System.out.println("SUM IS " + sum);
            centroids.add(sum / count);
            //System.out.println(centroids);
        }
        //System.out.println("ITER IS " + iter++ + "\nCENTROIDS ARE" + centroids);
        return centroids;
    }

    public Map<List<Double>, Integer> calculateClusters(List<List<Double>> irisCoords, Map<String, List<Double>> centroids) {
        Map<List<Double>, Integer> clusters = new HashMap<>();
        lastDistance = printingDistance;
        printingDistance = 0;
        int arrIn = 0;
        double distance;
        for (List<Double> irisCoord : irisCoords) {
            double minimum = Distance.euclideanDistance(centroids.get("0"), irisCoord);
            for (int j = 0; j < centroids.size(); j++) {
                distance = Distance.euclideanDistance(centroids.get(String.valueOf(j)), irisCoord); // find distance from every vector to every centroid
                if (distance <= minimum) {
                    minimum = distance;
                    arrIn = j;
                }
                //find min distance for every cluster and assign them to centroids basing on that
                /*if(!Double.isNaN(distance))*/
                printingDistance += distance;
                //else System.out.println("DISTANCE IS NAN");
            }
            clusters.put(irisCoord, arrIn);
        }
        //System.out.println("SIZE IS " + clusters.size());
//        System.out.println("CLUSTERS IN ITERATION " + numberOfIterations + " " + clusters + "\nSize is " + clusters.size());
        //System.out.println(clusters.values() + "\nSIZE IS " + clusters.size());
        System.out.println("Sum of distance is " + printingDistance);
        return clusters;
    }
}
